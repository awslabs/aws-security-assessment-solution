"""
The module checks to see if AWS Backup is enabled
for "EBS", "RDS", "EFS", "Storage Gateway"
"""

import boto3
import logging
import os
import cfnresponse
from botocore.exceptions import ClientError

"""
Set up logging
"""
LOG_FORMAT = "%(levelname)s %(asctime)s - %(message)s"
logging.basicConfig(level=logging.INFO, format = LOG_FORMAT)
logger = logging.getLogger()


def lambda_handler(event, context):
  if event['RequestType'] == 'Delete':
    cfnresponse.send(event, context, cfnresponse.SUCCESS, {})

  if event['RequestType'] == 'Create':

    backup_client = boto3.client('backup', region_name=os.environ["AWS_REGION"])
    ec2_client = boto3.client('ec2', region_name = os.environ["AWS_REGION"])

    BACKUP_ENABLED = False

    def list_backup_jobs(service_name):
        """
        Checks if the back up is enabled for
        an aws service
        """
        return backup_client.list_backup_jobs(
            ByResourceType = service_name
        )

    """
    Check for the backup for each service
    """

    services = ("DynamoDB","EBS", "RDS", "EFS", "Storage Gateway")

    try:
        backup_enabled_services = [service for service in services if len(list_backup_jobs(service)['BackupJobs'])>0]
        if len(backup_enabled_services) == 0:
            logger.warning("Please consider enabling backup more details\
                https://aws.amazon.com/backup/")
            string = "Please consider enabling backup more details."
            encoded_string = string.encode("utf-8")
            bucket_name = os.environ['reportbucket']
            file_name = "RansomwareCheck-Backup-fail"
            s3 = boto3.resource("s3")
            s3.Bucket(bucket_name).put_object(Key=file_name, Body=encoded_string)
        else:
            logger.info(f"Backup is enabled for {backup_enabled_services}")
            string = f"No issues found, Backup is enabled for {backup_enabled_services}"
            encoded_string = string.encode("utf-8")
            bucket_name = os.environ['reportbucket']
            file_name = "RansomwareCheck-Backup-OK"
            s3 = boto3.resource("s3")
            s3.Bucket(bucket_name).put_object(Key=file_name, Body=encoded_string)

    except (ClientError,
            backup_client.exceptions.InvalidParameterValueException,
            backup_client.exceptions.InvalidRequestException,
            backup_client.exceptions.ServiceUnavailableException) as e:
        logger.error(f'Error {e} encountered while checking for backup jobs')

    if len(backup_enabled_services) > 0:
        BACKUP_ENABLED = True
    responseData = {}
    cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)
    return BACKUP_ENABLED
