"""
The module identifies the roles that have S3 access that
has not been used in last 60 days

Todos:
* Need to extend to cover instance profiles
"""

import boto3
import logging
from botocore.exceptions import ClientError
from dateutil import tz
from datetime import datetime, timedelta
from dateutil import tz
import os
import cfnresponse
from dateutil.relativedelta import relativedelta

"""
Set up logging
"""
LOG_FORMAT = "%(levelname)s %(asctime)s - %(message)s"
logging.basicConfig(level=logging.INFO, format = LOG_FORMAT)
logger = logging.getLogger()

def lambda_handler(event, context):
  if event['RequestType'] == 'Delete':
    cfnresponse.send(event, context, cfnresponse.SUCCESS, {})
  if event['RequestType'] == 'Create':
    iam_client = boto3.client('iam')

    UNUSED_S3_ACCESS = False
    role_details = []

    """
    List all the roles that are in the accounts - RoleName, Arn, PolicyNames
    """

    for role_info in iam_client.list_roles()['Roles']:

        """
        Get all the IAM roles in the account
        """
        role_details.append(
            {
                'RoleName': role_info['RoleName'],
                'Arn': role_info['Arn'],
                'PolicyNames': iam_client.list_role_policies(RoleName = role_info['RoleName'])['PolicyNames'],

            }
        )


    def check_s3_access_for_role(roles):
        """
        The function identifies all the roles that have access to s3.

        Args:
            * roles (list(dict)): List of dictionaries containing roles - Arn, RoleName, PolicyNames

        Returns:
            * role_details_with_s3_access(list(dict)): List of roles that have 3 access
        """
        role_details_with_s3_access = []

        for role in roles:
            s3_access_policy_details = [ policies['Policies'] for policies in
                iam_client.list_policies_granting_service_access(
                    Arn=role['Arn'],
                    ServiceNamespaces=[
                        "s3"
                    ]
                )['PoliciesGrantingServiceAccess']
            ]
            for policy_details in s3_access_policy_details:
                if len(policy_details) > 0:
                    for p in policy_details:
                        role_details_with_s3_access.append(
                            {
                                'RoleName': role['RoleName'],
                                'Arn': role['Arn'],
                                'PolicyNames': role['PolicyNames'],
                                'S3AccessPolicy':p['PolicyName']
                            }
                        )

        return role_details_with_s3_access


    def check_s3_last_access_details(roles):
        """
        This function determines if the last access to s3 was done
        more than CHECK_THRESHOLD = 60 days ago

        Args:
            * roles (list(dict)): list of roles to check

        Returns:
            * roles_with_stale_access(list(dict)): List of roles that have not accessed s3 in last 60 days
                * Arn
                * RoleName
        """

        """
        Set the last access threshold to check for in days
        """
        CHECK_THRESHOLD = 60

        roles_with_stale_access = []


        for role in roles:
            """
            For reach role in the account, generate a report that includes details about
            when the role was last used in an attempt to access S3 services. Recent
            activity usually appears within four hours. IAM reports activity for the last
            365 days, or less if your Region began supporting this feature within the last year.
            """

            response = iam_client.generate_service_last_accessed_details(
            Arn = role['Arn'],
            Granularity = 'SERVICE_LEVEL'
            )


            while True:
                s3_last_accessed = iam_client.get_service_last_accessed_details(
                    JobId = response['JobId']
                )
                if s3_last_accessed['JobStatus'] in 'COMPLETED':
                    break


            """
            Check if the role was last used 60 days ago to access s3
            """

            for service in s3_last_accessed['ServicesLastAccessed']:

                if service['ServiceNamespace'] in 's3':
                    """ print(service)
                    print(role['RoleName']) """
                    now = datetime.now(tz=tz.UTC)
                    try:
                        last_accessed = relativedelta(now,service['LastAuthenticated'])
                        if last_accessed.days >= CHECK_THRESHOLD:
                            logger.warning(f'It has been {last_accessed.days} days that Role{role["RoleName"]} has accessed s3')
                            roles_with_stale_access.append(
                                {
                                    'RoleName': role['RoleName'],
                                    'Arn': role['Arn'],
                                    'DaysSinceLastAccess': last_accessed.days
                                }
                            )
                    except (KeyError):
                        pass

        return roles_with_stale_access

    if len(check_s3_last_access_details(check_s3_access_for_role(role_details))) > 0:
        UNUSED_S3_ACCESS = True
        encoded_string = str(roles_with_stale_access)
        bucket_name = os.environ['reportbucket']
        file_name = "RansomwareCheck-S3StaleAccess-Fail"
        s3 = boto3.resource("s3")
        s3.Bucket(bucket_name).put_object(Key=file_name, Body=encoded_string)
    else:
        encoded_string = "No issues found"
        bucket_name = os.environ['reportbucket']
        file_name = "RansomwareCheck-S3StaleAccess-OK"
        s3 = boto3.resource("s3")
        s3.Bucket(bucket_name).put_object(Key=file_name, Body=encoded_string)

    responseData = {}
    cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)
    return UNUSED_S3_ACCESS
