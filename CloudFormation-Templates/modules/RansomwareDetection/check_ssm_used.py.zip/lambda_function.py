"""
The module checks to see if there are running
EC2 instances that are not managed by SSM
"""

import boto3
import os
import logging
import cfnresponse
from botocore.exceptions import ClientError, EndpointConnectionError


"""
Set up logging
"""
LOG_FORMAT = "%(levelname)s %(asctime)s - %(message)s"
logging.basicConfig(level=logging.INFO, format = LOG_FORMAT)
logger = logging.getLogger()

def lambda_handler(event, context):

  if event['RequestType'] == 'Delete':
    cfnresponse.send(event, context, cfnresponse.SUCCESS, {})

  if event['RequestType'] == 'Create':

    ec2_client = boto3.client('ec2', region_name =os.environ['AWS_REGION'])

    SSM_ENABLED = False

    def get_ssm_inventory(aws_region):
        """
        Returns a list of instances managed by
        SSM in the region
        """
        managed_instances_in_the_region = []
        regional_ssm_client = boto3.client('ssm', region_name = aws_region)
        for instance in regional_ssm_client.get_inventory()['Entities']:
            managed_instances_in_the_region.append(instance['Id'])
        return managed_instances_in_the_region


    def running_instances_managed_by_ssm_in_the_region(aws_region):
        """
        Retruns a list of running instance that are managed by SSM
        in the specified region
        """
        regional_ssm_client = boto3.client('ssm', region_name=aws_region)
        managed_instances = regional_ssm_client.describe_instance_information()
        managed_instance_list = []
        for instance in managed_instances['InstanceInformationList']:
            managed_instance_list.append(instance['InstanceId'])
        return managed_instance_list

    def describe_instances(aws_region):
        """
        Returns a list of instances present in the
        region
        """
        instance_ids = []
        regional_ec2_client = boto3.client('ec2', region_name = aws_region)
        instances_in_region = regional_ec2_client.describe_instances(
        Filters = [
            {
                'Name':'instance-state-name',
                'Values': [
                'running',
                # 'stopped'
                ]
            }
            ])
        for instances in instances_in_region['Reservations']:
            for instance in instances['Instances']:
                instance_ids.append(instance['InstanceId'])
        return instance_ids

    instances_managed_by_ssm = []
    instances_in_account_all_regions = []

    current_regions = ec2_client.describe_regions()

    for region in current_regions['Regions']:
        instances_in_account_all_regions.append(describe_instances(region['RegionName']))
        try:
            instances_managed_by_ssm.append(running_instances_managed_by_ssm_in_the_region(aws_region=region['RegionName']))
        except EndpointConnectionError as e:
            pass

    instances_in_account_all_regions = [instance for instances in instances_in_account_all_regions for instance in instances]

    instances_managed_by_ssm = [instance for instances in instances_managed_by_ssm for instance in instances]

    if len(set(instances_in_account_all_regions) - set(instances_managed_by_ssm)) > 0:
        logger.warning(
            f'The following instances might not be managed by SSM:\
                {set(instances_in_account_all_regions) - set(instances_managed_by_ssm)}\
                    Consider enabling Systems Manager on all instances\
                        https://docs.aws.amazon.com/systems-manager/latest/userguide/systems-manager-quick-setup.html\
            '
        )
        string = f"The following instances might not be managed by SSM: {str(instances_in_account_all_regions)} {str(instances_managed_by_ssm)} Consider enabling Systems Manager on all instances\
            https://docs.aws.amazon.com/systems-manager/latest/userguide/systems-manager-quick-setup.html"
        encoded_string = string.encode("utf-8")
        bucket_name = os.environ['reportbucket']
        file_name = "RansomwareCheck-SSMCheck-Fail"
        s3 = boto3.resource("s3")
        s3.Bucket(bucket_name).put_object(Key=file_name, Body=encoded_string)

    else:
        SSM_ENABLED = True
        logger.info('Looks like SSM is managing running instances')
        string = "Looks like SSM is managing running instances"
        encoded_string = string.encode("utf-8")
        bucket_name = os.environ['reportbucket']
        file_name = "RansomwareCheck-SSMCheck-OK"
        s3 = boto3.resource("s3")
        s3.Bucket(bucket_name).put_object(Key=file_name, Body=encoded_string)

    responseData = {}
    cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)
    return SSM_ENABLED
