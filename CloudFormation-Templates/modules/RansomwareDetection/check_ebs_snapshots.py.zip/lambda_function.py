"""
The module checks to see if there are any EBS
Snapshots in the Account including:
* Snapshots in all regions
"""

import boto3
import logging
import os
import cfnresponse
from botocore.exceptions import ClientError

"""
Set up logging
"""
LOG_FORMAT = "%(levelname)s %(asctime)s - %(message)s"
logging.basicConfig(level=logging.INFO, format = LOG_FORMAT)
logger = logging.getLogger()

def lambda_handler(event, context):
  if event['RequestType'] == 'Delete':
    cfnresponse.send(event, context, cfnresponse.SUCCESS, {})

  if event['RequestType'] == 'Create':


    ec2_client = boto3.client('ec2')
    EBS_SNAPSHOTS_USED = False

    def describe_snapshots(aws_region):
        """
        Funtion returns snapshots available in a region

        Args:
            aws_region: AWS region to query

        Returns:
            Snapshots for the region (dict)
        """
        regional_ec2_client = boto3.client('ec2', region_name = aws_region)
        return regional_ec2_client.describe_snapshots(OwnerIds=['self'])

    """
    Snapshots in all regions
    """
    snapshot_count = 0

    current_regions = ec2_client.describe_regions()

    for region in current_regions['Regions']:
        available_snapshots = describe_snapshots(region['RegionName'])
        if len(available_snapshots['Snapshots']) > 0:
            snapshot_count +=1

    if snapshot_count == 0:
        string = "There are no snapshots present in the account. \
            Please refer to https://docs.aws.amazon.com/AWSEC2/latest/WindowsGuide/ebs-creating-snapshot.html \
                for information about creating snapshots"
        logger.warning(f"{string}")
        encoded_string = string.encode("utf-8")

        bucket_name = os.environ['reportbucket']
        file_name = "RansomwareCheck-EBSSnapShots-F"
        s3 = boto3.resource("s3")
        s3.Bucket(bucket_name).put_object(Key=file_name, Body=encoded_string)

    else:
        string = f"{str(snapshot_count)} Snapshots are enabled in the account.\
            Consider reviewing https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ec2-best-practices.html\
                to see the best practices related to EBS"

        logger.info(f"{snapshot_count} {string}")
        EBS_SNAPSHOTS_USED = True
        encoded_string = string.encode("utf-8")

        bucket_name = os.environ['reportbucket']
        file_name = "RansomwareCheck-EBSSnapShots-OK"
        s3 = boto3.resource("s3")
        s3.Bucket(bucket_name).put_object(Key=file_name, Body=encoded_string)

    responseData = {}
    cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)
    return EBS_SNAPSHOTS_USED
