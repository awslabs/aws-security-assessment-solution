"""
The module checks to see if there are any Access Keys that have not been used in 
last 90 days
https://docs.aws.amazon.com/general/latest/gr/aws-access-keys-best-practices.html
"""

import boto3
import logging
import os
from collections import defaultdict
import datetime
from datetime import datetime, timedelta 
from dateutil import tz
import cfnresponse
from botocore.exceptions import ClientError

"""
Set up logging
"""
LOG_FORMAT = "%(levelname)s %(asctime)s - %(message)s"
logging.basicConfig(level=logging.INFO, format = LOG_FORMAT)
logger = logging.getLogger()


session = boto3.Session()

iam_client = session.client('iam')

PARAMS = {
    'INACTIVITY_TIME': 90,
}

def save_results_on_s3(file_name, results):
    """Save the results of the check on S3
        Args:
            * file_name: Name of the file containing check results
            * results: Results that need to be saved on s3
        Returns:
            * -1: Upon error
    """
    encoded_string = results.encode("utf-8")
    bucket_name = os.environ['reportbucket']
    try:
        s3 = boto3.resource("s3")
        s3.Bucket(bucket_name).put_object(Key=file_name, Body=encoded_string)
    except ClientError as e:
        logger.error(f'{e} occured while saving the results for {file_name}')
        return -1

def list_user_access_keys():
    """Find the access keys that are in current account
        Args:
            *None
        Returns:
            *access_keys (dict): User name and access keys
    """
    users = list()
    access_keys = defaultdict(list)
    try:
        user_paginator = iam_client.get_paginator('list_users')
        user_response = user_paginator.paginate().build_full_result()
        [users.append(user.get('UserName')) for user in user_response.get('Users')]
        
        for user in users:
            response = iam_client.list_access_keys(UserName = user)
            for key_data in response.get('AccessKeyMetadata'):
                if key_data.get('Status') in 'Active':
                    access_keys[user].append(key_data.get('AccessKeyId'))
        return access_keys
    except ClientError as e:
        logger.error(f'{e} while getting Access Keys')
        return -1

def find_unused_keys(user_access_keys = list_user_access_keys(), inactivity_threshold = PARAMS.get("INACTIVITY_TIME")):
    """Find access keys that have not been used in given time
        Args:
            *user_access_keys: Access Keys for each user
            *inactivity_threshold: Access key inactivity time period
        Returns:
            -1: Upon error
            inactive_user_keys (dict): Users with inactive keys
    """
    user_names = user_access_keys.keys()
    inactive_user_keys = defaultdict(list)
    try:
        for user in user_names:
            for key in user_access_keys.get(user):
                response = iam_client.get_access_key_last_used(
                                AccessKeyId = key,
                            )
                
                if response.get('AccessKeyLastUsed').get('LastUsedDate'):
                    days_since_last_use = datetime.now(tz=tz.tzlocal()) - response.get('AccessKeyLastUsed').get('LastUsedDate')
                    if days_since_last_use >= timedelta(days = inactivity_threshold):
                        inactive_user_keys[user].append(key)
                else:
                    inactive_user_keys[user].append(key)
        return inactive_user_keys
    except ClientError as e:
        logger.error(f'{e} while accessing last used details for access keys')
        return -1

def __format_output(unused_keys = find_unused_keys(), inactivity_threshold = PARAMS.get("INACTIVITY_TIME")):
    """Formats the access keys for output
        Args:
            *unused_keys(dict): Access keys that are unused
            *inactivity_threshold: Access key inactivity time period
        Returns:
            *result(str): The result that can be stored in S3
    """
    users = unused_keys.keys()
    result = f'Following users have access keys that have not been used in last {inactivity_threshold} days:\n'
    result += '------------------------------------------------------------\n'

    result += "User Name"+'\t'+"Access Keys"+'\n'
    result += '------------------------------------------------------------\n'
    for user in users:
        if len(unused_keys.get(user)) > 1:
            result += user+'\t'
            for key in unused_keys.get(user):
                result += key+'\t'
        else:
            for key in unused_keys.get(user):
                result += user+'\t'+key
        result += '\n'
    return result

def __results(unused_keys = find_unused_keys()):
    """Check if there are unused keys
        Args: 
            *unused_keys(dict): Access keys that are unused
        Returns:
            *True: If unused keys
            *False: If no unused keys
    """
    if unused_keys.keys():
        return True
    else:
        return False


def lambda_handler(event, context):
    if event['RequestType'] == 'Delete':
        cfnresponse.send(event, context, cfnresponse.SUCCESS, {})
    
    if event['RequestType'] == 'Create':
        unused_keys = find_unused_keys()
        if __results(unused_keys):
            save_results_on_s3("Stale_access_key_check_failed",
            __format_output(unused_keys))
        else:
            save_results_on_s3("Stale_access_key_check_passed",
                    "No stale access keys found"
                )
        responseData = {}
        cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)



