"""
The module scans if the GuardDuty is enabled in the 
Account:
*   across all regions
*   integrated with AWS Organizations provided Organizations 
    is currently enabled in the account 

"""

import boto3
import logging
import botocore
from botocore.exceptions import ClientError, EndpointConnectionError


"""
Set up logging
"""
LOG_FORMAT = "%(levelname)s %(asctime)s - %(message)s"
logging.basicConfig(level=logging.INFO, format = LOG_FORMAT)
logger = logging.getLogger()

GUARDDUTY_ENABLED_IN_ALL_REGIONS = False

"""
Check if the detectors are enabled.

A detector is a resource that represents 
the GuardDuty service. To start using GuardDuty, 
you must create a detector in each Region where 
you enable the service. You can have only one 
detector per account per Region.
"""
detector_enabled = ""

ec2_client = boto3.client('ec2')
regions = ec2_client.describe_regions()
region_names = [ region['RegionName'] for region in regions['Regions']]

def check_guardduty(region_names = region_names, logger = logger):
    """
    Check for GuardDuty across all regions

    Args:
        *   region_names: List of the currently available regions in 
            the partition
    
    Returns:
        * Bool: True if GuardDuty is enabled across all available regions 
    """
    
    count = 0
    for region in region_names:
        guardduty_client = boto3.client('guardduty', region_name=region)
        try:
            detector_enabled = guardduty_client.list_detectors()
            if len(detector_enabled['DetectorIds']) > 0:
                logger.info(f"GuardDuty is enabled in region {region}")

        except (ClientError, guardduty_client.exceptions.BadRequestException, guardduty_client.exceptions.InternalServerErrorException) as e:
            logger.error(e)
            logger.info(f"Please enable GuardDuty https://docs.aws.amazon.com/guardduty/latest/ug/guardduty_settingup.html in region {region}")
            count +=1
        
        except EndpointConnectionError:
            pass

    if count:
        logger.info(f'GuardDuty not enabled in {count} regions')
        return False
    return True

def _check_organizations_enabled():
        organizations_client = boto3.client('organizations')
        try:
            result = organizations_client.describe_organization()
            if result['Organization']['Id']:
                return True
        except ClientError:
            logger.info('Account not part of an Organization')
            return False 

def check_organizations_integration(logger = logger):
    """
    Check if GuardDuty is integrated with Organizations

    Args:
        * None
    
    Returns:
        * Bool: True if integrated

    """
    if _check_organizations_enabled():
        guardduty_client = boto3.client('guardduty')
        result = guardduty_client.list_organization_admin_accounts()
        if not result['AdminAccounts']:
            logger.info('Consider using GuardDuty with AWS Organizations '
                'https://docs.aws.amazon.com/guardduty/latest/ug/guardduty_organizations.html')
            return False
        return True 

def main():
    GUARDDUTY_ENABLED_IN_ALL_REGIONS = check_guardduty()
    GUARDDUTY_INTEGRATED_WITH_ORGANIZATIONS = check_organizations_integration()
    responseData = {}
    cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)
    return GUARDDUTY_ENABLED_IN_ALL_REGIONS


def lambda_handler(event, context):
    main()
