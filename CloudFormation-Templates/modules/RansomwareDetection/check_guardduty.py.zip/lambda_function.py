"""
The module scans if the GuardDuty is enabled in the
Account
"""

import boto3
import os
import logging
import cfnresponse
from botocore.exceptions import ClientError

def lambda_handler(event, context):
  if event['RequestType'] == 'Delete':
    cfnresponse.send(event, context, cfnresponse.SUCCESS, {})

  if event['RequestType'] == 'Create':

    guardduty_client = boto3.client('guardduty')

    """
    Set up logging
    """
    LOG_FORMAT = "%(levelname)s %(asctime)s - %(message)s"
    logging.basicConfig(level=logging.INFO, format = LOG_FORMAT)
    logger = logging.getLogger()

    GUARDDUTY_ENABLED = False

    """
    Check if the detectors are enabled.

    A detector is a resource that represents
    the GuardDuty service. To start using GuardDuty,
    you must create a detector in each Region where
    you enable the service. You can have only one
    detector per account per Region.
    """
    detector_enabled = ""

    try:
        detector_enabled = guardduty_client.list_detectors()
        if len(detector_enabled['DetectorIds']) > 0:
            logger.info("GuardDuty is enabled")
            GUARDDUTY_ENABLED = True
            string = str(detector_enabled)
            encoded_string = string.encode("utf-8")
            bucket_name = os.environ['reportbucket']
            file_name = "RansomwareCheck-GuardDuty-OK"
            s3 = boto3.resource("s3")
            s3.Bucket(bucket_name).put_object(Key=file_name, Body=encoded_string)


    except (ClientError, guardduty_client.exceptions.BadRequestException, guardduty_client.exceptions.InternalServerErrorException) as e:
        logger.error(e)
        logger.info("Please enable GuardDuty https://docs.aws.amazon.com/guardduty/latest/ug/guardduty_settingup.html")
        string = "Please enable GuardDuty https://docs.aws.amazon.com/guardduty/latest/ug/guardduty_settingup.html"
        encoded_string = string.encode("utf-8")
        bucket_name = os.environ['reportbucket']
        file_name = "RansomwareCheck-GuardDuty-Fail"
        s3 = boto3.resource("s3")
        s3.Bucket(bucket_name).put_object(Key=file_name, Body=encoded_string)
    responseData = {}
    cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)

    return GUARDDUTY_ENABLED
