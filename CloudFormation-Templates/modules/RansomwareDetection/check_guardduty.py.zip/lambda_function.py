"""
The module scans if the GuardDuty is enabled in the
Account:
*   across all regions
*   integrated with AWS Organizations provided Organizations
    is currently enabled in the account

"""

import boto3
import logging
import os
import botocore
from botocore.exceptions import ClientError, EndpointConnectionError
import cfnresponse


"""
Set up logging
"""
LOG_FORMAT = "%(levelname)s %(asctime)s - %(message)s"
logging.basicConfig(level=logging.INFO, format = LOG_FORMAT)
logger = logging.getLogger()

GUARDDUTY_ENABLED_IN_ALL_REGIONS = False

"""
Check if the detectors are enabled.

A detector is a resource that represents
the GuardDuty service. To start using GuardDuty,
you must create a detector in each Region where
you enable the service. You can have only one
detector per account per Region.
"""
detector_enabled = ""

s3 = boto3.resource("s3")
bucket_name = os.environ['reportbucket']

ec2_client = boto3.client('ec2')
regions = ec2_client.describe_regions()
region_names = [ region['RegionName'] for region in regions['Regions']]

def check_guardduty(region_names = region_names, logger = logger):
    """
    Check for GuardDuty across all regions

    Args:
        *   region_names: List of the currently available regions in
            the partition

    Returns:
        * Bool: True if GuardDuty is enabled across all available regions
    """

    count = 0
    guradduty_not_enabled_regions = []
    for region in region_names:
        guardduty_client = boto3.client('guardduty', region_name=region)
        try:
            detector_enabled = guardduty_client.list_detectors()
            if len(detector_enabled['DetectorIds']) > 0:
                logger.info(f"GuardDuty is enabled in region {region}")
            else:
                guradduty_not_enabled_regions.append(region)
                count +=1

        except (ClientError, guardduty_client.exceptions.BadRequestException, guardduty_client.exceptions.InternalServerErrorException) as e:
            logger.error(e)
            logger.info(f"Please enable GuardDuty https://docs.aws.amazon.com/guardduty/latest/ug/guardduty_settingup.html in region {region}")
            guradduty_not_enabled_regions.append(region)
            count +=1

        except EndpointConnectionError:
            pass

    if count:
        logger.info(f'GuardDuty not enabled in {count} regions')
        string = f"GuardDuty is not enabled in {count} region(s). Please check GuardDuty settings in {guradduty_not_enabled_regions} region(s)"
        file_name = 'RansomwareCheck-GuardDutyCheck-Fail'
        encoded_string = string.encode('utf-8')
        s3.Bucket(bucket_name).put_object(Key=file_name, Body=encoded_string)

        return False
    string = "Looks like GuardDuty is enabled across all regions"
    file_name = 'RansomwareCheck-GuardDutyCheck-Pass'
    encoded_string = string.encode('utf-8')
    s3.Bucket(bucket_name).put_object(Key=file_name, Body=encoded_string)
    return True

def _check_organizations_enabled():
        organizations_client = boto3.client('organizations')
        try:
            result = organizations_client.describe_organization()
            if result['Organization']['Id']:
                return True
        except ClientError:
            logger.info('Account not part of an Organization')
            return False

def check_organizations_integration(logger = logger):
    """
    Check if GuardDuty is integrated with Organizations

    Args:
        * None

    Returns:
        * Bool: True if integrated

    """
    if _check_organizations_enabled():
        guardduty_client = boto3.client('guardduty')
        try:
            result = guardduty_client.list_organization_admin_accounts()
            if not result['AdminAccounts']:
                logger.info('Consider using GuardDuty with AWS Organizations '
                    'https://docs.aws.amazon.com/guardduty/latest/ug/guardduty_organizations.html')
                string = "Looks like GuardDuty is NOT integrated with Organizations"
                file_name = 'RansomwareCheck-GuardDutyOrganizationsIntegrationCheck-Fail'
                encoded_string = string.encode('utf-8')
                s3.Bucket(bucket_name).put_object(Key=file_name, Body=encoded_string)
                return False
            string = "Looks like GuardDuty is integrated with Organizations"
            file_name = 'RansomwareCheck-GuardDutyOrganizationsIntegrationCheck-Pass'
            encoded_string = string.encode('utf-8')
            s3.Bucket(bucket_name).put_object(Key=file_name, Body=encoded_string)
            return True
        except ClientError:
            logger.info('Account is not the Org Master')
            return False


def lambda_handler(event, context):
  if event['RequestType'] == 'Delete':
    cfnresponse.send(event, context, cfnresponse.SUCCESS, {})

  if event['RequestType'] == 'Create':
    GUARDDUTY_ENABLED_IN_ALL_REGIONS = check_guardduty()
    GUARDDUTY_INTEGRATED_WITH_ORGANIZATIONS = check_organizations_integration()
    responseData = {}
    cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)
    return GUARDDUTY_ENABLED_IN_ALL_REGIONS