"""
The module identifies if the logging is configured for different services relevant to ransomware
"""

import boto3
import logging
import os
import re
import botocore
from botocore.exceptions import ClientError
from collections import defaultdict
import cfnresponse

"""
Set up logging
"""
LOG_FORMAT = "%(levelname)s %(asctime)s - %(message)s"
logging.basicConfig(level=logging.INFO, format = LOG_FORMAT)
logger = logging.getLogger()

session = boto3.Session()

boto_session = botocore.session.get_session()

logging_check_message = ''

LOGGING_ENABLED = False

def get_available_regions():
    """Return the list of available regions
        Args: 
            * None
        Returns:
            * region_names: Names of the regions
    """
    ec2_client = boto3.client('ec2')
    response = ec2_client.describe_regions(AllRegions=False)
    region_names = list()
    for region in response.get('Regions'):
        region_names.append(region.get('RegionName'))
    return region_names

def save_results_on_s3(file_name, results):
    """Save the results of the check on S3
        Args:
            * file_name: Name of the file containing check results
            * results: Results that need to be saved on s3
        Returns:
            * -1: Upon error
    """
    encoded_string = results.encode("utf-8")
    bucket_name = os.environ['reportbucket']
    try:
        s3 = boto3.resource("s3")
        s3.Bucket(bucket_name).put_object(Key=file_name, Body=encoded_string)
    except ClientError as e:
        logger.error(f'{e} occured while saving the results for {file_name}')
        return -1

PARAMS={
    'SERVICES': ['cloudfront', 'ecs', 'eks', 'fsx', 'lambda', 'network-firewall', 'rds', 'route53', 'route53resolver', 's3', 'wafv2',]
}
SERVICE_LOGGING_STATUS = defaultdict(bool)
# Check logging params for CloudFront

def _check_cloudfront_distribution_logging(cf_client, distribution_id):
    """Validate if the distribution has logging enabled
        Args:
            * cf_client (boto3.client): CloudFront client
            * distribution_id (str): The distribution's ID
        Returns:
            * -1: Upon error
            * None: If no distribution found
            * logging_status (bool): Based on the logging config
    """
    if not distribution_id:
        return None
    try:
        response = cf_client.get_distribution(
            Id = distribution_id,
        )
        return response.get('Distribution').get('DistributionConfig').get('Logging').get('Enabled')
    except ClientError as e:
        logger.error(f'{e} occured while checking the distribution {distribution_id} status')
        return -1

def _get_available_distributions(cf_client):
    """Return the available Cloud Front distributions in a region

        Args:
            * cf_client (boto3.client): CloudFront client        
        Returns:
            * -1: Upon error
            * distribution_ids (list): Distributions available in a region
    """
    distribution_ids = list()
    try:
        paginator = cf_client.get_paginator('list_distributions')
        response = paginator.paginate().build_full_result()
        if not response:
            return
        for distribution in response.get('DistributionList').get('Items'):
            distribution_ids.append(distribution.get('Id'))
        return distribution_ids
    except ClientError as e:
        logger.error(f'{e} occured while checking the distributions')
        return -1

def check_cloudfront_logging():
    """Checks if the CloudFront distributions have logging enabled 

        Args:
            * regions (list): List of available regions
        
        Returns:
            * -1: Upon error
            * message (str): current logging status
    """
    distribution_logging_status = list()
    cf_client = session.client('cloudfront')
    message = ''

    cf_distributions = _get_available_distributions(cf_client)
    if cf_distributions:
        for distribution_id in cf_distributions:
            if not _check_cloudfront_distribution_logging(cf_client, distribution_id):
                distribution_logging_status.append(
                    distribution_id
                )
        message = "Following distributions do not have logging enabled"
        message += "\n-------------------------------------------------"
        for i, item in enumerate(distribution_logging_status,start=1):
            message +=f'\n{i}: {item}'
        message += "\nRefer https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/AccessLogs.html to enable logging."
        return message
    else:
        LOGGING_ENABLED = False
        return None
if not 'us-gov' in os.environ['AWS_REGION']:
    cloudfront_message = check_cloudfront_logging()
    if cloudfront_message:
        logging_check_message += cloudfront_message
        SERVICE_LOGGING_STATUS['cloudfront'] = False
    
    else:
        logging_check_message += 'CloudFront seem to be logging'
        SERVICE_LOGGING_STATUS['cloudfront'] = True
    
    logging_check_message +=  '\n'
    logging_check_message += '====================================================\n'
    # Check lambda application logs

def _get_available_lambda_functions():
    """Identify the functions present in a region
        Args:
            * region_name (str): Name of the region to check
        Returns:
            * functions_names (defaultdict): Functions in the region
    """
    available_regions = boto_session.get_available_regions('lambda')
    functions_names = defaultdict(list)
    
    if 'us-gov' in os.environ['AWS_REGION']:
        available_regions = ['us-gov-east-1', 'us-gov-west-1']
    
    for region in available_regions:
        #logger.info(f'checking for lambda functions in region {region}')
        try:
            lambda_client = boto3.client('lambda', region_name=region)
            paginator = lambda_client.get_paginator('list_functions')
            response = paginator.paginate().build_full_result()
            for function in response.get('Functions'):
                functions_names[region].append(function.get('FunctionName'))
                    
        except ClientError as e:
            logger.error(f'{e} occured while checking functions in region {region}')
            continue

    return functions_names

def _get_lambda_cloudwatch_loggroups(function_details = _get_available_lambda_functions()):
    """Get the cloudwatch log groups in the region where lambda functions exist
        Args:
            * function_details (defaultdict): Available functions in the account
        Returns:
            * -1: Upon error
            * message: The result of check
    """
    if not function_details:
        return None
    regions = function_details.keys()
    functions_with_no_log_groups = defaultdict(list)
    message = ''
    log_group_pattern = r'/aws/lambda/(.*)'
    regex = re.compile(log_group_pattern)
    for region in regions:
        functions_names = function_details.get(region)
        
        log_groups = list()
        try:
            cw_client = boto3.client('logs', region_name = region)
            paginator = cw_client.get_paginator('describe_log_groups')
            response = paginator.paginate().build_full_result()
            for group in response.get('logGroups'):
                if '/aws/lambda/' in group.get('logGroupName'):

                    matches = regex.findall(group.get('logGroupName'))
                    log_groups.append(matches[0])
            
            missing_functions = list(set(functions_names) - set(log_groups))
            if missing_functions:
                functions_with_no_log_groups[region] = missing_functions
        except ClientError as e:
            logger.error(f'{e} occured while checking log groups in region {region}')
            return -1
    message += 'Following lambda functions do not seem to have CloudWatch logging enabled or they might not have been executed+\n'
    message += "--------------------------------------------------------------------------"

    for region in functions_with_no_log_groups.keys():
        message += f'\nRegion {region}:\n'
        message += '+++++++++++++++++++++\n'
        
        for function in functions_with_no_log_groups.get(region):
            message += '- '+function+'\n'
    return message
        

lambda_message = _get_lambda_cloudwatch_loggroups()
if lambda_message:
    logging_check_message+=lambda_message
    logging_check_message+= '\nCheck https://docs.aws.amazon.com/lambda/latest/dg/monitoring-cloudwatchlogs.html for further details.'
    SERVICE_LOGGING_STATUS['lambda'] = False
else:
    logging_check_message += 'Lambdas seem to be logging to CloudWatch'
    SERVICE_LOGGING_STATUS['lambda'] = True

logging_check_message +=  '\n'
logging_check_message += '====================================================\n'

# Check Route 53 Query Logging

def _get_route53_query_logging():
    """Zones with query logging configured
        Args:
            None
        Returns:
            * hosted_zone_ids_with_logging (list): Zone IDs that have logging configured
    """
    hosted_zone_ids_with_logging = list()

    try:
        route53_client = session.client('route53')
        paginator = route53_client.get_paginator('list_query_logging_configs')
        response = paginator.paginate().build_full_result()

        if not response.get('QueryLoggingConfigs'):
            return 'No query logging configured'
        else:
            for config in response.get('QueryLoggingConfigs'):
                hosted_zone_ids_with_logging.append(
                    config.get('HostedZoneId')
                )
        return hosted_zone_ids_with_logging
    except ClientError as e:
        pass

def validate_query_logging(zone_ids_with_logging = _get_route53_query_logging()):
    """Identify the public hosted zones without logging
        Args:
            *zone_ids_with_logging (list): List of public hosted zones without query logging
        Returns:
            message (str): Zones without logging
            None: If all zones have logging
    """
    config_link = 'https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/query-logs.html'
    message = f'Following public zones do not have query logging configured.\nRefer to {config_link} on how to configure the logging\n'
    message += "---------------------------------------------------------------\n"
    hosted_zones_ids = defaultdict(str)

    try:
        route53_client = session.client('route53')
        paginator = route53_client.get_paginator('list_hosted_zones')
        response = paginator.paginate().build_full_result()
        for zone in response.get('HostedZones'):
            if not zone.get('Config').get('PrivateZone'):
                hosted_zones_ids[zone.get('Id').split('/')[-1]] = zone.get('Name')
        if not hosted_zones_ids.values():
            return
        ids = list(set(hosted_zones_ids.keys()) - set(zone_ids_with_logging))
        if not ids:
            return None
        for id in ids:
            message += '- '+'Domain Name: '+hosted_zones_ids.get(id)+' Id: '+ id+'\n'
            return message
    except ClientError as e:
        pass

route53_query_logging_message = validate_query_logging()

if route53_query_logging_message:
    SERVICE_LOGGING_STATUS['route53'] = False
    logging_check_message += route53_query_logging_message

else:
    logging_check_message += 'Public HostedZones seem to be logging to CloudWatch'
    SERVICE_LOGGING_STATUS['route53'] = True

logging_check_message +=  '\n'
logging_check_message += '====================================================\n'

# Check Route 53 Resolver Logging

def get_available_regions_for_service(service_name):
    """Returns available regions for the service
        Args:
            * service_name (str): Name of the service to check
        Returns:
            * available_regions (list): List of available regions
    """
    session = botocore.session.get_session()
    return session.get_available_regions(service_name)

def get_vpcs(region_name):
    """Returns the list of VPCs in a given region
        Args: 
            *region_name: Region to check for available vpcs
        Returns:
            * vpcs(list): Available vpcs in the region
    """
    try:
        ec2_client = boto3.client(
            'ec2',
            region_name=region_name,
        )
        paginator = ec2_client.get_paginator('describe_vpcs',)
        response = paginator.paginate().build_full_result()
        response = ec2_client.describe_vpcs()
        vpc_details = response.get('Vpcs')
        vpcs = list()
        for vpc in vpc_details:
            vpcs.append(vpc.get('VpcId'))
        
        return vpcs

    except ClientError as e:
        pass
    
def _get_vpc_ids_with_query_logging(region_name):
    """Identify VPCs in a regionthat have query resolver logging enabled
        Args:
            * region_name (str): Query resolver region
        Returns:
            * vpc_ids(list): List of VPCs that have logging enabled
    """
    vpc_ids = list()
    try:
        route53resolver_client = session.client('route53resolver', region_name=region_name)
        paginator = route53resolver_client.get_paginator('list_resolver_query_log_config_associations')
        response = paginator.paginate().build_full_result()
        for association in response.get('ResolverQueryLogConfigAssociations'):
            if association.get('Status') in 'ACTIVE':
                vpc_ids.append(
                    association.get('ResourceId')
                )
        return vpc_ids
    except ClientError as e:
        pass


def validate_query_resolver_logging():
    """Identify vpcs that do not have query logging enabled
        Args:
            *zone_ids_with_logging (list): List of public hosted zones without query logging
        Returns:
            message (str): Zones without logging
            None: If all zones have logging
    """
    config_link = 'https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/resolver-query-logs.html'
    message = f'Following vpcs do not have query logging configured.\nRefer to {config_link} on how to configure the logging\n'
    message += "---------------------------------------------------------------\n"
    
    hosted_zones_ids = defaultdict(str)

    available_regions = get_available_regions_for_service('route53resolver')

    vpcs_missing_query_logging = set()
    query_logging_enabled = False
    vpcs_without_query_logging = list()
    
    for region_name in available_regions:
        
        vpcs_with_logging = _get_vpc_ids_with_query_logging(region_name)
        available_vpcs_in_region = get_vpcs(region_name)
        message += f'Region {region_name}:\n'
        message += '**************************\n'

        if vpcs_with_logging:
            vpcs_missing_query_logging = set(available_vpcs_in_region) - set(vpcs_with_logging)
            if vpcs_missing_query_logging:
                for vpc_id in vpcs_missing_query_logging:
                    message += '- '+vpc_id+'\n'
                    vpcs_without_query_logging.append(vpc_id)
            else:
                message += '- '+'All VPCs configured'+'\n'
        elif not available_vpcs_in_region:
            pass
        else:
            for vpc_id in available_vpcs_in_region:
                message += '- '+vpc_id+'\n'
                vpcs_without_query_logging.append(vpc_id)
        message += '**************************\n'

    if not vpcs_without_query_logging:
        return 
    else:
        return message


query_resolver_logging_message = validate_query_resolver_logging()

if query_resolver_logging_message:
    SERVICE_LOGGING_STATUS['route53resolver'] = False
    logging_check_message += query_resolver_logging_message

else:
    logging_check_message += 'All VPCs seem to have query logging configured'
    SERVICE_LOGGING_STATUS['route53resolver'] = True

logging_check_message +=  '\n'
logging_check_message += '====================================================\n'

  
def lambda_handler(event, context):
    if event['RequestType'] == 'Delete':
        cfnresponse.send(event, context, cfnresponse.SUCCESS, {})

    if event['RequestType'] == 'Create':
        # Store results on S3
        if False in SERVICE_LOGGING_STATUS.values():
            save_results_on_s3('LoggingCheckFailed', logging_check_message)
        else:
            save_results_on_s3('LoggingCheckPassed', logging_check_message)
        responseData = {}
        cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)