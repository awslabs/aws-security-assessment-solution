"""
The module scans the currently running ec2 instances for:
* Windows 2008 R2 (EOL Jan 2020)
"""

import boto3
import logging
import os
import cfnresponse
from botocore.exceptions import ClientError, EndpointConnectionError


"""
Set up logging
"""
LOG_FORMAT = "%(levelname)s %(asctime)s - %(message)s"
logging.basicConfig(level=logging.INFO, format = LOG_FORMAT)
logger = logging.getLogger()

def lambda_handler(event, context):
  if event['RequestType'] == 'Delete':
    cfnresponse.send(event, context, cfnresponse.SUCCESS, {})

  if event['RequestType'] == 'Create':

    WINDOWS_2008_SERVER_PRESENT = False

    COUNT_OF_2008_SYSTEMS = 0
    WINDOWS_2008_SERVER_INSTANCE_IDS = []


    def find_windows_2008(region_name=''):
        """
        The function checks for 2008 managed instances and

        Ags:
            * region_name: AWS Region

        Returns:
            * a list of Instance Ids of Windows 2008, or
            * Nothing if no Windows 2008 present

        """
        regional_ssm_client = boto3.client('ssm', region_name = region_name)

        logger.info(f'Running checks for Windows Server 2008 in region: {region_name}')

        windows_2008_system_instance_ids = []

        instance_information = regional_ssm_client.describe_instance_information(
            Filters = [
                {
                    'Key': 'PlatformTypes',
                    'Values': [
                        "Windows"
                    ]
                }
            ]
        )
        for instance in instance_information['InstanceInformationList']:
            instance_id = instance['InstanceId']
            platform_name = instance['PlatformName']

            print(f'{instance_id} {platform_name}')
            if '2008' in platform_name:

                windows_2008_system_instance_ids.append(instance_id)

        if len(windows_2008_system_instance_ids) > 0:
            return windows_2008_system_instance_ids
        else:
            return

    ec2_client = boto3.client('ec2')

    """
    Iterate over currently available regions
    """

    current_regions = ec2_client.describe_regions()

    for region in current_regions['Regions']:
        try:
            windows_2008_in_region = find_windows_2008(region_name=region['RegionName'])

            if type(windows_2008_in_region) is list:
                WINDOWS_2008_SERVER_INSTANCE_IDS.append(windows_2008_in_region)
        except EndpointConnectionError as e:
            pass

        except ClientError as e:
                logger.error(f'{e} encountered')


    WINDOWS_2008_SERVER_INSTANCE_IDS = [ i for instances in WINDOWS_2008_SERVER_INSTANCE_IDS for i in instances]

    COUNT_OF_2008_SYSTEMS = len(WINDOWS_2008_SERVER_INSTANCE_IDS)

    if COUNT_OF_2008_SYSTEMS > 0:
        WINDOWS_2008_SERVER_PRESENT = True
        logger.warning(f'There are {COUNT_OF_2008_SYSTEMS} instances that might be running Windows Server 2008.\
            Consider upgrading them as soon as possible to mitigate Ransomware threats')
        logger.warning(f'Instance IDs of the 2008 systems are {WINDOWS_2008_SERVER_INSTANCE_IDS}')

        string = f"There are {COUNT_OF_2008_SYSTEMS} instances that might be running Windows Server 2008.\
            Consider upgrading them as soon as possible to mitigate Ransomware threats.\
            Instance IDs of the 2008 systems are {WINDOWS_2008_SERVER_INSTANCE_IDS}"
        encoded_string = string.encode("utf-8")
        bucket_name = os.environ['reportbucket']
        file_name = "RansomwareCheck-OutdatedOS-FAIL"
        s3 = boto3.resource("s3")
        s3.Bucket(bucket_name).put_object(Key=file_name, Body=encoded_string)
    else:
        string = "No issues found"
        encoded_string = string.encode("utf-8")
        bucket_name = os.environ['reportbucket']
        file_name = "RansomwareCheck-OutdatedOS-OK"
        s3 = boto3.resource("s3")
        s3.Bucket(bucket_name).put_object(Key=file_name, Body=encoded_string)
        
    responseData = {}
    cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)
    return WINDOWS_2008_SERVER_PRESENT
