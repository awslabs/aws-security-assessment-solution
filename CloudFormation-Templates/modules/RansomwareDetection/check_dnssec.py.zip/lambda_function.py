"""
The module checks to see if DNSSEC is enabled for 
public hosted zones in Amazon Route 53
https://aws.amazon.com/about-aws/whats-new/2020/12/announcing-amazon-route-53-support-dnssec/
"""

import boto3
import logging
import os
import cfnresponse
from botocore.exceptions import ClientError

"""
Set up logging
"""
LOG_FORMAT = "%(levelname)s %(asctime)s - %(message)s"
logging.basicConfig(level=logging.INFO, format = LOG_FORMAT)
logger = logging.getLogger()


session = boto3.Session()

route53_client = session.client('route53')

def get_public_hosted_zones():
    """List all the public hosted zones
        Args:
            * None 
        Returns:
            * hosted_public_zones (list): List of public hosted zones
            * -1: Upon error
    """
    hosted_public_zones = list()
    try:
        zone_response = route53_client.list_hosted_zones()
        while True:
            for zone in zone_response.get('HostedZones'):
                if not zone.get('Config').get('PrivateZone'):
                    hosted_public_zones.append(zone.get('Id'))
            if zone_response.get('NextMarker'):
                zone_response = route53_client.list_hosted_zones(Marker = zone_response.get('NextMarker'))
            else:
                return hosted_public_zones

    except ClientError as e:
        logger.error(f'{e} occurred while fetching the public zones')
        return -1


def check_dnssec_status(hosted_zone_id: str):
    """Checks if DNSSEC is enabled on the zone

        Args:
            * hosted_zone_id: A unique string used to identify a hosted zone.
        
        Returns:
            * dnssec_enabled (bool): Status of the DNSSEC on the zone
            * -1: Upon error
    """
    dnssec_enabled = False
    
    try:
        dnssec_response = route53_client.get_dnssec(
        HostedZoneId= hosted_zone_id
        )
        if dnssec_response.get('Status').get('ServeSignature') == 'SIGNING':
            logger.info(f'DNNSEC is enabled for {hosted_zone_id}')
            return True
        else:
            return False

    except ClientError as e:
        logger.error(f'{e} occured while checking the DNSSEC status of {hosted_zone_id}')
        return -1

def get_hosted_zone_details(hosted_zone_id):
    """Returns the details of the hosted zone
        Args:
            * hosted_zone_id: The ID of the hosted zone that you want to get information about
        Returns:
            * -1: Upon error
            *  zone_details (str): Name and VPCId of the zone
    """
    try:
        response = route53_client.get_hosted_zone(
            Id = hosted_zone_id
        )
        associated_vpc_ids = list()
        if response.get('VPCs'):
            [associated_vpc_ids.append(vpc.get('VPCId')) for vpc in response.get('VPCs')]
        
            message = ''
            for vpc_id in associated_vpc_ids:
                message = vpc_id+' '

            return f"Zone-Id: {hosted_zone_id}\t Name: {response.get('HostedZone').get('Name')} associated with VPCIds: {message}"
        else:
            return f"Zone-Id: {hosted_zone_id}\t Name: {response.get('HostedZone').get('Name')}"
    except ClientError as e:
        logger.error(f'{e} occured while checking for {hosted_zone_id} details')
        return -1

def save_results_on_s3(file_name, results):
    """Save the results of the check on S3
        Args:
            * file_name: Name of the file containing check results
            * results: Results that need to be saved on s3
        Returns:
            * -1: Upon error
    """
    encoded_string = results.encode("utf-8")
    bucket_name = os.environ['reportbucket']
    try:
        s3 = boto3.resource("s3")
        s3.Bucket(bucket_name).put_object(Key=file_name, Body=encoded_string)
    except ClientError as e:
        logger.error(f'{e} occured while saving the results for {file_name}')
        return -1


def lambda_handler(event, context):
    if event['RequestType'] == 'Delete':
        cfnresponse.send(event, context, cfnresponse.SUCCESS, {})

    if event['RequestType'] == 'Create':
        check_results = ''
        zones_with_no_dnssec = list()
        public_hosted_zones = get_public_hosted_zones()

        for zone in public_hosted_zones:
            if not check_dnssec_status(zone):
                zones_with_no_dnssec.append(zone)

        for zone in zones_with_no_dnssec:
            check_results += '- '+get_hosted_zone_details(zone) + '\n'

        check_results = 'DNSSEC is not enabled for:\n'+ check_results

        if zones_with_no_dnssec:
            file_name = 'DNSSEC Check Failed'
            save_results_on_s3(file_name = file_name, results=check_results)
        elif public_hosted_zones:
            file_name = 'DNSSEC Check Passed'
            save_results_on_s3(file_name = file_name, results = f'Check passed for {public_hosted_zones}')
        else:
            file_name = 'DNSSEC Check Not Applicable'
            save_results_on_s3(file_name = file_name, results = 'No public hosted zones found in the account')
        responseData = {}
        cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)
        return 


