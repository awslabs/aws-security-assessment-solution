"""
The module checks to see if DNS Firewall is enabled across all relevant regions
https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/resolver-dns-firewall.html
"""

import boto3
import logging
import os
import cfnresponse
from botocore.exceptions import ClientError



"""
Set up logging
"""
LOG_FORMAT = "%(levelname)s %(asctime)s - %(message)s"
logging.basicConfig(level=logging.INFO, format = LOG_FORMAT)
logger = logging.getLogger()

session = boto3.Session()

def get_available_regions():
    """Return the list of available regions
        Args: 
            * None
        Returns:
            * region_names: Names of the regions
    """
    ec2_client = boto3.client('ec2')
    response = ec2_client.describe_regions(AllRegions=False)
    region_names = list()
    for region in response.get('Regions'):
        region_names.append(region.get('RegionName'))
    return region_names

def get_vpcs(region_name):
    """Returns the list of VPCs in a given region
        Args: 
            *region_name: Region to check for available vpcs
        Returns:
            * vpcs(list): Available vpcs in the region
    """
    ec2_client = boto3.client(
        'ec2',
        region_name=region_name,
    )

    response = ec2_client.describe_vpcs()
    vpc_details = response.get('Vpcs')
    #print(response)
    vpcs = list()
    
    try:
        while True:
            for vpc in vpc_details:
                vpcs.append(vpc.get('VpcId'))
            if not response.get('NextToken'):
                return vpcs
            response = ec2_client.descibe_vpcs(
                NextToken = response.get('NextToken')
            )
    except ClientError as e:
        logger.error(f'{e} occured while getting the vpcs in {region_name}')
        return -1
    

def save_results_on_s3(file_name, results):
    """Save the results of the check on S3
        Args:
            * file_name: Name of the file containing check results
            * results: Results that need to be saved on s3
        Returns:
            * -1: Upon error
    """
    encoded_string = results.encode("utf-8")
    bucket_name = os.environ['reportbucket']
    try:
        s3 = boto3.resource("s3")
        s3.Bucket(bucket_name).put_object(Key=file_name, Body=encoded_string)
    except ClientError as e:
        logger.error(f'{e} occured while saving the results for {file_name}')
        return -1


def check_dns_firewall_status_ORIG(region_name):
    """Check if there is a DNS firewall and if it is 
        associated with available VPCs
        Args:
            *region_name: Name of the region to check
        Returns:
            * dns_firewall_status
            * -1: Upon error
    """
    resolver_client = session.client(
        'route53resolver',
        region_name=region_name,
    )
    vpcs_with_dns_firewall = list()
    try:
        response = resolver_client.list_firewall_configs()
        while True:
            # Check if the firewall is enabled
            if response.get('FirewallConfigs'):
                for config in response.get('FirewallConfigs'):
                    print(config)
                    vpcs_with_dns_firewall.append(config.get('ResourceId'))
            if not response.get('NextToken'):
                return vpcs_with_dns_firewall
            response = resolver_client.list_firewall_configs(
                NextToken = response.get('NextToken')
            )
  
    except resolver_client.exceptions.AccessDeniedException as e:
        logger.error(f'{e} occured while checking the status of DNS firewall in {region_name}. Check your credentials please')
        return -1
    
    except ClientError as e:
        logger.error(f'{e} occured while checking the status of DNS firewall in {region_name}')
        return -1

def check_dns_firewall_status(region_name):
    """Check if there is a DNS firewall and if it is 
        associated with available VPCs
        Args:
            *region_name: Name of the region to check
        Returns:
            * dns_firewall_status
            * -1: Upon error
    """
    resolver_client = session.client(
        'route53resolver',
        region_name=region_name,
    )
    vpcs_with_dns_firewall = list()
    rule_group_ids = list()
    try:
        rule_group_response = resolver_client.list_firewall_rule_groups()
        while True:
            if rule_group_response.get('FirewallRuleGroups'):
                [rule_group_ids.append(group_id.get('Id')) for group_id in rule_group_response.get('FirewallRuleGroups')]
            if not rule_group_response.get('NextToken'):
                break
            rule_group_response = resolver_client.list_firewall_rule_groups(
                NextToken = rule_group_response.get('NextToken'),
            )
        
        if rule_group_ids:
            for rule_group_id in rule_group_ids:
                response = resolver_client.list_firewall_rule_group_associations(
                    FirewallRuleGroupId = rule_group_id,
                )
                while True:
                    # Get the VpcIds for the vpcs associated with a rule group
                    if response.get('FirewallRuleGroupAssociations'):
                        for association in response.get('FirewallRuleGroupAssociations'):
                            vpcs_with_dns_firewall.append(association.get('VpcId'))
                       
                    if not response.get('NextToken'):
                        return vpcs_with_dns_firewall
                    response = resolver_client.list_firewall_rule_group_associations(
                    FirewallRuleGroupId = rule_group_id,
                    NextToken = response.get('NextToken')
                )
            
    except resolver_client.exceptions.AccessDeniedException as e:
        logger.error(f'{e} occured while checking the status of DNS firewall in {region_name}. Check your credentials please')
        return -1
    
    except ClientError as e:
        logger.error(f'{e} occured while checking the status of DNS firewall in {region_name}')
        return -1

def get_vpcs_with_no_dns_fw():
    """Returns VPCs per region that are not 
        associated with a DNS firewall
        Args:
            *None
        Returns:
            *dns_firewall_status(list): List of vpcs across each 
                region that do not have DNS firewall
    """
    dns_firewall_status = list()
    for region_name in get_available_regions():
        available_vpcs = get_vpcs(region_name)
        vpcs_with_firewall = check_dns_firewall_status(region_name)
        if isinstance(vpcs_with_firewall, list):
            vpcs_with_no_dns = set(available_vpcs) - set(vpcs_with_firewall)
            dns_firewall_status.append(
                {
                    'region_name': region_name,
                    'vpcs_with_no_dns_firewall': vpcs_with_no_dns
                }
            )
        else:
            dns_firewall_status.append(
                {
                    'region_name': region_name,
                    'vpcs_with_no_dns_firewall': available_vpcs
                }
            )
    return dns_firewall_status

def create_check_results(results = get_vpcs_with_no_dns_fw()):
    """Create the results that will be posted on S3
        Args:
            *results: The dictionary containing VpcIds that do not have
                DNS firewall within each region
        Returns:
            *message(str): Message that will be posted on S3
    """
    if results:
        message = "Following vpcs do not have Route 53 Firewall associated:\n"
        message+= "---------------------------------------------------------\n"

        for region in results:
            message += f'\n{region.get("region_name")}:\n'
            for count, vpc in enumerate(region.get('vpcs_with_no_dns_firewall'),1):
                message += f'{count}. {vpc}\n'
            message+= "---------------------------------------------------------\n"
        return message
    return

def store_results():
    """Store the check results on S3
        Args:
            *None
        Returns:
            * None
    """
    message = create_check_results()

    if message:
        file_name = "DNS-Firewall-check-failed"
        save_results_on_s3(file_name, message)
    else:
        file_name = "DNS-Firewall-check-passed"
        save_results_on_s3(file_name, "Your VPCs seem to be associated with DNS Firewall")

def lambda_handler(event, context):
    if event['RequestType'] == 'Delete':
        cfnresponse.send(event, context, cfnresponse.SUCCESS, {})
    
    if event['RequestType'] == 'Create':
        store_results()
        responseData = {}
        cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)


