import json
import os
import boto3
import cfnresponse

def lambda_handler(event, context):
  if event['RequestType'] == 'Delete':
    cfnresponse.send(event, context, cfnresponse.SUCCESS, {})

  if event['RequestType'] == 'Create':

     bucket_name = os.environ['reportbucket']
     ssm_doc_name = os.environ['ssm_name']
     ec2_client = boto3.client('ec2')
     running_instances = [instance.get('InstanceId') for instance in ec2_client.describe_instance_status().get('InstanceStatuses') if instance.get('InstanceState').get('Code')==16]
     ssm_client = boto3.client('ssm')
     print(running_instances[0])
     response = ssm_client.send_command(DocumentName=ssm_doc_name,
        InstanceIds=running_instances,
         Comment='Ransomware Scan',
        TimeoutSeconds=600,
        OutputS3BucketName=bucket_name,
        OutputS3KeyPrefix=f"{str(running_instances)}_report")
     responseData = {}
     cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)
